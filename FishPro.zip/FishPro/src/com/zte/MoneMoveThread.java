package com.zte;

public class MoneMoveThread extends Thread{
	public Money m;
	public MoneMoveThread(Money m){
		this.m = m;
	}
	public void run(){
		while(m.isLive){
			
			try {
				Thread.sleep(2000);
				m.isLive=false;
				m.panel.ms.remove(m);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
