package com.zte;

import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Fish {
	public int x;//������
	public int y;//������
	public int imgNum = 0;//��ǰ��ʾ��ͼƬ�±�
	public ImageIcon imgs[];//���ͼƬ
	
	public boolean isCatch = false;//�Ƿ񱻲�
	boolean isMove = true;
	public ImageIcon[] imgsCatch;
	public int road=0;//�ƶ�·��
	public int step = 2;//�ƶ����ٶ�
	public int timeThread = 30;
	FishPanel panel;
	public static int right_to_left = 1;
	public static int up_to_buttom = 2;
	public static int left_to_right = 3;
	public int money;//ÿ�����õĽ��
	public int hp;//Ѫ��
	public Fish(FishPanel panel){
		this.panel = panel;
	}
	//�����ͼƬ
    public void drawFish(Graphics g) {
    	if(isCatch){
    	    g.drawImage(imgsCatch[imgNum%2].getImage(), x, y,panel);
    	}else{
    		g.drawImage(imgs[imgNum%10].getImage(), x, y,panel);
    	}
    }
    //���ζ�
    public void move(){
    	//���û����
    	if(!isCatch){
    		switch(road){
    		case 1:
    			x = x-step;
    			if(x<-imgs[imgNum].getIconWidth()){
    				panel.fishs.remove(this);
    			}
    			 break;
    		case 2:
    			y = y + step;
    			if(y>panel.getHeight()){
    				panel.fishs.remove(this);
    			}
    			break;
    		case 3:
    			x = x+step;
    			if(x>panel.getWidth()){
    				panel.fishs.remove(this);
    			}
    			break;
    		}
    	}else{//ץס���Ƴ�
    		 
    		panel.fishs.remove(this);
    	}
    	
    	imgNum++;
		if(imgNum>=imgs.length && !isCatch){
			imgNum = 0;
		}
		if(imgNum>=imgsCatch.length && isCatch){
		imgNum = 0;
	 }
		
    	panel.repaint();
    }
}
