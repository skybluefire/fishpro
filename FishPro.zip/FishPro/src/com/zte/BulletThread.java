package com.zte;

public class BulletThread extends Thread{
	public Bullet  bullet;
	public BulletThread(Bullet bullet){
		this.bullet = bullet;
	}
	public void run(){
		while(bullet.isLive){
			try {
				bullet.move();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
