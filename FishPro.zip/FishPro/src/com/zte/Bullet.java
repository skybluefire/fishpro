package com.zte;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import javax.swing.ImageIcon;

public class Bullet {
	public int x;// ������
	public int y;// ������

	static int xxx = 0;
	static int yyy = 0;
	Point p;
	public ImageIcon img;// �ӵ�������ͼƬ
	public double roate;// �ӵ��ƶ��ĽǶ�
	public FishPanel panel;
	boolean isLive = true;

	public Bullet(FishPanel panel) {
		this.panel = panel;
	}

	public void move() throws InterruptedException {
		y -= 20;
		// ת��x��y����
		int yy = Math.round((float) Math.cos(roate) * (p.y - 17 - y));
		yyy = p.y - 17 - Math.abs(yy);
		int xx = Math.round((float) Math.sin(roate) * (p.y - 17 - y));
		xxx = p.x - 20 + xx;
		if (yyy<=-10 || xxx <= -20) {
			isLive = false;
			panel.bullets.remove(this);
		}
		hint();
		
		panel.repaint();
	}

	// ��������ĳ���� ����
	public void hint() throws InterruptedException{
		for(int i=0;i<panel.fishs.size();i++){
			Fish f = panel.fishs.get(i);
			if(xxx>f.x-img.getIconWidth() && xxx<f.x
					+f.imgs[f.imgNum].getIconWidth() && y<f.y
					+f.imgs[f.imgNum].getIconHeight()){
				FishNet net = new FishNet(xxx-30, yyy-50, 
						new ImageIcon("images/web.png"),panel);			   
			    panel.bullets.remove(this);//�ӵ���ʧ
			    panel.nets.add(net);//�ӵ���ʧ������
			    isLive = false;
			    
			    net.caFish();
			    
			    /*******************/
			    Thread.sleep(500);//��2��֮��������ʧ
			    panel.nets.remove(net);
			}
		}
		
	}

	public void drawBullet(Graphics g) {
		Graphics2D gp = (Graphics2D) g.create();
		gp.rotate(roate, p.x, p.y);
		gp.drawImage(this.img.getImage(), x,y,
				this.img.getImage().getWidth(panel)*panel.a,
				this.img.getImage().getHeight(panel)*panel.a, panel);
	}
}
