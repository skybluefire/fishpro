package com.zte;

public class FishThread extends Thread{
	Fish fish;
	
	public FishThread(Fish fish){
		this.fish = fish;
	}
	public void run(){
		while(fish.isMove&&!FishPanel.isOver){
			try {
				Thread.sleep(fish.timeThread);
//				System.out.println("123");
				fish.move();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
