package com.zte;
//���
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.*;

public class FishPanel extends JPanel implements MouseListener,MouseMotionListener,Runnable{
	int a=1;
	int d=1;
  int score=0;
   int bullet_num=50;
   public int width; //���ڵĿ���
   public int height;  //���ڵĸ߶�
   public int barrelX;  //��Ͳ��ͼƬ������
   public int barrelY;  // ��Ͳ��������
   double roate; //��Ͳ�ĽǶ�
   int mouseX=0;
   int mouseY=0;
   
   static boolean isOver=false;//��Ϸ�Ƿ�����ı���
   static boolean isWin=false;//��Ϸ�Ƿ�����ı���
   ArrayList<Fish> fishs=new ArrayList<Fish>();
   ArrayList<Bullet> bullets = new ArrayList<Bullet>();
   ArrayList<FishNet> nets=new ArrayList<FishNet>();
   ArrayList<Money> ms=new ArrayList<Money>();
   public FishPanel(int width,int height){
	   this.width=width;
	   this.height=height;
	   barrelX=416;
	   barrelY=this.height-62;
	   this.setLayout(null);
	   
   }
   //��дpaint()����
   public void paint(Graphics g){
	  super.paint(g);
	  Image bgImg=null;
	  Image bgImg1=null;
	  Image bgImg2=null;
	  if(a<=7)
		  bgImg=new ImageIcon("images/bg_0"+a+".png").getImage();    //��������ͼ
	  else
		  bgImg=new ImageIcon("images/bg_0"+(a-7)+".png").getImage();    //��������ͼ 
	  bgImg1=new ImageIcon("images/bg1.jpg").getImage();     //��ʾ����ͼƬ
	  bgImg2=new ImageIcon("images/solider.png").getImage(); //����
	  //������ͼ
	  g.drawImage(bgImg,0,0,this);
	  g.drawImage(bgImg1,15,this.height-72,this);
	  Image rightAdd=new ImageIcon("images/ui_button_65_hv.png").getImage();  //�Ӻ�ͼ��
	  
	  g.drawImage(rightAdd,498,this.height-35,50,40,this);
	  Image lefeSub=new ImageIcon("images/ui_button_63_hv.png").getImage();   //����ͼ��
	  g.drawImage(lefeSub,338,this.height-35,50,40,this);
	  g.drawImage(bgImg2,560,453,this);
	 
		g.setFont(new Font("΢���ź�", Font.BOLD, 28));
		g.setColor(Color.red);
		g.drawString("" + score % 10 + "", 150, 478);
		g.drawString("" + (score / 10 % 10), 127, 478);
		g.drawString("" + (score / 100 % 10), 104, 478);
		g.drawString("" + (score / 1000 % 10), 81, 478);
		g.drawString("" + (score / 10000 % 10), 58, 478);
		g.drawString("" + (score / 100000 % 10), 36, 478);
		
		//���ӵ�����
		g.setColor(Color.white);
		g.setFont(new Font("����", Font.BOLD, 15));
		g.drawString("BULLET-NUM:", 10, 20);
		g.drawString(""+bullet_num, 120, 20);
		g.drawString("LEVEL:" + a, 180, 20);
	  //����
		for(int i=0;i<fishs.size();i++){
			Fish f=(Fish)fishs.get(i);
			f.drawFish(g);
		}
		// ���ӵ�
		for (int i = 0; i < bullets.size(); i++) {
			Bullet b = bullets.get(i);
			b.drawBullet(g);
		}
		//������
		for (int i = 0; i < nets.size(); i++) {
			FishNet n = nets.get(i);
			n.drawNet(g);
		}
		//������
		for (int i = 0; i < ms.size(); i++) {
			Money m = ms.get(i);
			m.drawMoney(g);
				}
		
	  //����Ͳ
	   Image barrel=new ImageIcon("images/pt"+d+".png").getImage();
	   int x=barrelX+19;
	   int y=barrelY+39;
	   double y1=(double)mouseY-y;
	   double x1=(double)mouseX-x;
	   double f=-Math.atan(x1/y1);
	
	   if(f<=-Math.PI/2)
		   f=-Math.PI/2;
	   if(f>=Math.PI/2)
		   f=Math.PI/2;
	   roate=f;
	   Graphics2D gp=(Graphics2D)g;
	   gp.rotate(f,x,y);
	   gp.drawImage(barrel,barrelX,barrelY,this);
   }
   @Override
   public void mouseMoved(MouseEvent e) {
   	this.mouseX=e.getX();//������
   	this.mouseY=e.getY();//������
   	FishPanel.this.repaint();
   	
   }
   @Override
   public void run() {
	   while(!isOver){
		   
		   if(score>=5*a){
	   			isWin=true;	
//	   			this.removeMouseListener(this); //��������ƶ�
//	   			this.removeMouseMotionListener(this);
	   			Object[] options ={ "��һ��" };  
	   			int m = JOptionPane.showOptionDialog(null, "                  ��ʤ��", "��ϲ����",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);  
	   			nets.removeAll(fishs);
	   			fishs.removeAll(fishs);
	   			bullets.removeAll(bullets);
	   			ms.remove(ms);
	   			a++;
	   			score=0;
	   			bullet_num=50*a;
	   			
		   }
  	   		if(bullet_num<=0){
  	   			isOver=true;
  	   			this.removeMouseListener(this); //��������ƶ�
  	   			this.removeMouseMotionListener(this);
  	   			JOptionPane.showMessageDialog(null,"�����ӵ������꣬��Ϸ������");
  	   		}
  	   	
   	try{
   		
   		Thread.sleep(30);
//   		System.out.println("123");
   	}catch(Exception e){
   		e.printStackTrace();
   	}
   	
	   }
   }
     
@Override
public void mouseClicked(MouseEvent e) {
	
	
}
@Override
public void mouseEntered(MouseEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public void mouseExited(MouseEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public void mousePressed(MouseEvent e) {
	if (e.getY() < this.height - 50) {
		Bullet bullet = new Bullet(FishPanel.this);
		bullet.img = new ImageIcon("images/pd"+d+".png");
		bullet.x = barrelX + 19 - 10;
		bullet.y = barrelY + 39 - 17;
		bullet.roate = roate;
		bullet.p = new Point(barrelX + 19, barrelY + 39);
		bullets.add(bullet);
		BulletThread t = new BulletThread(bullet);
		t.start();
		bullet_num--;
	}
	if(e.getY() > this.height - 50&&e.getX()<518 &&e.getX() >478&&d<5) {
		d++;
		}
	if(e.getY() > this.height - 50&&e.getX()<368 &&e.getX() >328&&d>1) {
		d--;
		}
	
}
@Override
public void mouseReleased(MouseEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public void mouseDragged(MouseEvent e) {
	
	
}

}

























