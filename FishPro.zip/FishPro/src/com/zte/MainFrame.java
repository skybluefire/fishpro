package com.zte;

//����������
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.*;

public class MainFrame extends JFrame implements ActionListener {
	JLabel mainLabel;
	FishPanel panel; // ���
	JButton min, close;// ��С�����رհ�ť

	public MainFrame() {
		// ���幹�췽������ʼ������
		ImageIcon bg=new ImageIcon("images/bg.png");
		ImageIcon bg_03=new ImageIcon("images/bg_03.png");
		setUndecorated(true);
		setIconImage(new ImageIcon("images/icon.jpg").getImage());
		mainLabel = new JLabel(bg);
		setBounds(100, 100, bg.getIconWidth(), bg.getIconHeight());
		// ����������
		panel = new FishPanel(bg_03.getIconWidth(), bg_03.getIconHeight());
		panel.setBounds(14, 50, bg_03.getIconWidth(), bg_03.getIconHeight());
		mainLabel.add(panel);
    
		// ���ô�����Ը�������ƶ���͸��
		LocationUtil util = new LocationUtil(this);
		util.setOp();
		
		min = new JButton(new ImageIcon("images/min.png"));
		min.setBounds(740, 13, 32, 32);
		min.setBorderPainted(false);// ȥ����ť�ı߿�
		min.setContentAreaFilled(false); // ȥ����ť���������
		mainLabel.add(min);
		close = new JButton(new ImageIcon("images/close.png"));
		close.setBounds(780, 13, 32, 32);
		close.setBorderPainted(false);
		close.setContentAreaFilled(false);
		mainLabel.add(close);
       
		add(mainLabel);
		setVisible(true);
		min.addActionListener(this);
		close.addActionListener(this);
		
		panel.addMouseMotionListener(panel);
		panel.addMouseListener(panel);
		Thread th=new Thread(panel);
		th.start();//�������߳�
		
	}
	public void addFish() {
		new Thread() {
			public void run() {
				while(!FishPanel.isOver) {
					Fish f = new Fish(panel);
					ImageIcon[] imgs = new ImageIcon[10];
					ImageIcon[] caImgs = new ImageIcon[2];
					int road = (int) (Math.random() * 3) + 1;
					int kind = (int) (Math.random() * 9) + 1;
					if(kind==1){
						f.timeThread=40;
						f.money = 2;
						f.hp=1;
					}else if(kind==2){
						f.timeThread=60;
						f.money = 2;
						f.hp = 1;
					}else if(kind==3){
						f.timeThread=60;
						f.money = 2;
						f.hp = 1;
					}else if(kind==4){
						f.timeThread=60;
						f.money = 2;
						f.hp=1;
					}else if(kind==5){
						f.timeThread=60;
						f.money = 4;
						f.hp=2;
					}else if(kind==2){
						f.timeThread=60;
						f.money = 4;
						f.hp=2;
					}else if(kind==6){
						f.timeThread=60;
						f.money = 4;
						f.hp=2;
					}else if(kind==7){
						f.timeThread=60;
						f.money = 6;
						f.hp=3;
					}else if(kind==8){
						f.timeThread=70;
						f.money = 6;
						f.hp = 3;
					}else if(kind==9){
						f.timeThread=60;
						f.money = 8;
						f.hp=4;
					}
					String path = "";
					if (road == 1) {
						path = "images/right_to_left/fish"
								+ (kind < 10 ? "0" + kind : kind + "") + "_";
						int height = (int) (Math.random() * panel.getHeight()) - 100;
						f.x = 1000;
						f.y = height;

					} else if (road == 2) {
						path = "images/up_to_buttom/fish"
								+ (kind < 10 ? "0" + kind : kind + "") + "_";
						int width = (int) (Math.random() * panel.getWidth());
						f.x = width;
						f.y = -100;
					} else if (road == 3) {
						path = "images/left_to_right/fish"
								+ (kind < 10 ? "0" + kind : kind + "") + "_";
						int height = (int) (Math.random() * panel.getHeight()) - 100;
						f.y = height;
						f.x = -300;
					}
					for (int i = 1; i <= 2; i++) {
						String path1 = path + "catch_0"
								+ i + ".png";
						ImageIcon icon = new ImageIcon(path1);
						caImgs[i - 1] = icon;
					}
					for (int i = 1; i <= 10; i++) {
						String path1 = path + (i < 10 ? "0" + i : i + "")
								+ ".png";
						ImageIcon icon = new ImageIcon(path1);
						imgs[i - 1] = icon;
					}
					f.imgs = imgs;
					f.imgsCatch = caImgs;
					f.road = road;
					panel.fishs.add(f);
					FishThread t = new FishThread(f);
					t.start();
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}.start();

	}

	//��ʱ��
	public void paint(Graphics g){
		g.setFont(new Font("�����п�",Font.BOLD,30));
		g.setColor(Color.white);		
		Date date=new Date();repaint();
		super.paint(g);
		g.drawString(date.toLocaleString(), 300, 35);		
	}
	
	public static void main(String args[]) {
		MainFrame mframe=new MainFrame();
		mframe.addFish();
	}
    
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == min) {// ��С������
			this.setState(JFrame.ICONIFIED);
		} else if (e.getSource() == close) {
			System.exit(0);// �˳�����
		}

	}


}



















