package com.zte;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.ImageIcon;
public class Money {
	int x;
	int y;

	int count = 0;
	public boolean isLive = true;
	ImageIcon icon;
	FishPanel panel;
	ArrayList<Fish> catchF = new ArrayList<Fish>();
	public Money(int x,int y,FishPanel panel,Fish f){
		this.panel = panel;
		this.x = x;
		this.y = y;
		
	}
  public void graw(){
	  count++;
	  if(count>=5){
		  x = -100;
		  y=-100;
		  isLive = false;
	  }
  }
  
 
     //����
      public void drawMoney(Graphics g) {
           g.drawImage(new ImageIcon("images/goldItem.png").getImage(), x, y,panel);
       }
}
