package com.zte;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.ImageIcon;
public class FishNet {
	int x;
	int y;
	int sizex=50;
	int sizey=50;
	int count = 0;
	public boolean isLive = true;
	ImageIcon icon;
	FishPanel panel;
	ArrayList<Fish> catchF = new ArrayList<Fish>();
	public FishNet(int x,int y,ImageIcon icon,FishPanel panel){
		this.panel = panel;
		this.x = x;
		this.y = y;
		this.icon = icon;
	}
  public void graw(){
	  count++;
	  if(count>=5){
		  x = -100;
		  y=-100;
		  isLive = false;
	  }
  }
  //������
  public void caFish(){
			for(int j=0;j<panel.fishs.size();j++){
				Fish f = panel.fishs.get(j);
				if(f.x>this.x-(f.imgs[0].getIconWidth()/2)
						+5 && f.x+f.imgs[f.imgNum].getIconWidth()/2<this.x
						+this.icon.getIconWidth()
						 && f.y>this.y-(f.imgs[0].getIconHeight()/2)
						 +5 && f.y+f.imgs[f.imgNum].getIconHeight()/2<this.y
						 +this.icon.getIconHeight()){
					f.hp--;
					 if(f.hp==0){
						 panel.fishs.get(j).isCatch = true; 
						 catchF.add(f);
						 Money m = new Money(f.x,f.y,panel,f);
						 panel.ms.add(m);
						 panel.score+=f.money;
						 new MoneMoveThread(m).start();
					 }
				}
			}
	}
 
     //����
      public void drawNet(Graphics g) {
           g.drawImage(icon.getImage(), x, y, sizex*panel.a,sizey*panel.a,panel);
       }
}
